export const SORT_CATEGORY = [
  { id: 1, label: "최신순", sortOption: "latest" },
  { id: 2, label: "좋아요순", sortOption: "likes" },
  { id: 3, label: "조회순", sortOption: "views" },
];
